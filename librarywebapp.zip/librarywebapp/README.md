# 1.Structure

1.1 public route<br>
1.1.1 route "/"<br>
show public base page "base.html", and navigate "/listbooks" and "/loanbook"<br>
1.1.2 route "/listbooks"<br>
show public booklist page "booklist.html" and pass the book information list<br>
1.1.2 route "/loanbook"<br>
show public loan booklist page "addloan.html" and pass on information about books available for loan<br>
<br>

1.2 staff route<br>
1.2.1 route "/staff"<br>
show staff base page "staff.html", and navigate "/staff/listbooks","/staff/loadbook","/staff/listborrowers","/staff/currentloans","/staff/currentloans" and "/staff/overdue_report" <br>

1.2.2 route "/staff/listbooks" <br>
show staff book list page "staff_booklist.html" and pass the book information list.
staff can see how many times books have been loaned in total.<br>

1.2.3 route "/staff/loadbook" <br>
show staff loan book page "staff_addloan.html", pass loanable book list.
staff can click loan button to go to the "staff_loan_detail.html" and loan book to borrowers<br>

1.2.4 route "/staff//staff/listborrowers" <br>
show staff borrower list page "staff_borrowerlist.html", pass borrower list.
staff can edit,add borrower information and see the number of times the borrower has borrowed.<br>

1.2.5 route "/staff/currentloans" <br>
show staff current loans page "currentloans.html", pass current loan list data.
staff can check the current loan information and include whether they are overdue, and can return the books<br>

1.2.6 route "/staff/overdue_report" <br>
show staff overdue report page "staff_over_report", pass over report list data.
staff can see a list of all overdue books & their borrowers.<br>

# 2. Assumptions and Design decisions

In this library management system, staff and public pages are not shared, which can prevent public from operating the book system and improve security.<br>
And for requests involving database operations, only POST is accepted, because POST is more secure than GET.<br>
When lending books, all borrower information should be queried and select should be used for selection to prevent errors as borrowerid in the borrowing record does not exist in the database.<br>

# 3. Change

Add login function and token authentication to improve system security.
