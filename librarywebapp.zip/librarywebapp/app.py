from flask import Flask
from flask import render_template
from flask import request
from flask import redirect
from flask import url_for
import re
from datetime import datetime
import mysql.connector
from mysql.connector import FieldType
import connect

app = Flask(__name__)
app.jinja_env.auto_reload = True
dbconn = None
connection = None

def getCursor():
    global dbconn
    global connection
    connection = mysql.connector.connect(user=connect.dbuser, \
    password=connect.dbpass, host=connect.dbhost, \
    database=connect.dbname, autocommit=True)
    dbconn = connection.cursor()
    return dbconn

@app.route("/")
def home():
    return render_template("base.html")

@app.route("/listbooks")
def listbooks():
    connection = getCursor()
    connection.execute("SELECT * FROM books;")
    bookList = connection.fetchall()
    return render_template("booklist.html", booklist = bookList)    

@app.route("/select_books", methods=["POST"])
def select_books():
    title = request.form.get("title")
    author = request.form.get("author")
    connection = getCursor()
    connection.execute("""SELECT * FROM books where booktitle like %s and author like %s;""", ("%"+title+"%","%"+author+"%"))
    bookList = connection.fetchall()
    return render_template("booklist.html", booklist = bookList)  

@app.route("/loanbook")
def loanbook():
    todaydate = datetime.now().date()
    connection = getCursor()
    connection.execute("SELECT * FROM borrowers;")
    borrowerList = connection.fetchall()
    sql = """SELECT * FROM bookcopies
inner join books on books.bookid = bookcopies.bookid
 WHERE bookcopyid not in (SELECT bookcopyid from loans where returned <> 1 or returned is NULL);"""
    connection.execute(sql)
    bookList = connection.fetchall()
    return render_template("addloan.html", loandate = todaydate,borrowers = borrowerList, books= bookList)

@app.route("/staff")
def staffhome():
    return render_template("staff.html")

@app.route("/staff/listbooks")
def staffListbooks():
    connection = getCursor()
    connection.execute("""select books.*, count(l.returned)
    from books inner join bookcopies bk on bk.bookid = books.bookid
    right JOIN loans l on l.bookcopyid = bk.bookcopyid
    group by books.bookid;""")
    bookList = connection.fetchall()
    return render_template("staff_booklist.html", booklist = bookList)    

@app.route("/staff/select_books", methods=["POST"])
def staffselectbooks():
    title = request.form.get("title")
    author = request.form.get("author")
    connection = getCursor()
    connection.execute("""SELECT * FROM books where booktitle like %s and author like %s;""", ("%"+title+"%","%"+author+"%"))
    bookList = connection.fetchall()
    return render_template("staff_booklist.html", booklist = bookList)  

@app.route("/staff/loadbook")
def staffLoanbook():
    todaydate = datetime.now().date()
    connection = getCursor()
    connection.execute("SELECT * FROM borrowers;")
    borrowerList = connection.fetchall()
    sql = """SELECT * FROM bookcopies
inner join books on books.bookid = bookcopies.bookid;"""
    connection.execute(sql)
    bookList = connection.fetchall()
    return render_template("staff_addloan.html", loandate = todaydate,borrowers = borrowerList, books= bookList)

@app.route("/staff/listborrowers")
def staffListborrowers():
    connection = getCursor()
    connection.execute("""select borrowers.*, count(loans.returned)
from borrowers left JOIN loans on borrowers.borrowerid = loans.borrowerid
GROUP by borrowers.borrowerid;""")
    borrowerList = connection.fetchall()
    return render_template("staff_borrowerlist.html", borrowerlist = borrowerList)

@app.route("/staff/select_borrowers", methods=["POST"])
def staff_select_borrowers():
    firstname = request.form.get("firstname")
    borrowerid = request.form.get("borrowerid")
    connection = getCursor()
    connection.execute("""SELECT * FROM borrowers where firstname like %s and borrowerid like %s;""", ("%"+firstname+"%","%"+borrowerid+"%"))
    borrowerList = connection.fetchall()
    return render_template("staff_borrowerlist.html", borrowerlist = borrowerList)

@app.route("/staff/borrower_detail/<borrower_id>", methods=["POST", "GET"])
def staffBorrowerDetail(borrower_id):
    connection = getCursor()
    connection.execute("""SELECT * FROM borrowers where borrowerid=%s;""" %borrower_id)
    borrower = connection.fetchone()
    return render_template("staff_detail.html", borrower=borrower)

@app.route("/staff/update_borrower", methods=["POST"])
def staffUpdateBorrower():
    borrowerid = request.form.get("borrowerid")
    firstname = request.form.get("firstname")
    familyname = request.form.get("familyname")
    dateofbirth = request.form.get("dateofbirth")
    housenumbername = request.form.get("housenumbername")
    street = request.form.get("street")
    town = request.form.get("town")
    city = request.form.get("city")
    postalcode = request.form.get("postalcode")
    connection = getCursor()
    connection.execute("UPDATE borrowers SET firstname=%s, familyname=%s, dateofbirth=%s, housenumbername=%s, street=%s, town=%s, city=%s, postalcode=%s where borrowerid=%s;", (firstname, familyname, dateofbirth, housenumbername, street, town, city, postalcode, borrowerid))

    return redirect("/staff/listborrowers")

@app.route("/staff/add_borrower_detail")
def staffAddBorrowerDetail():
    return render_template("staff_add_borrower.html")

@app.route("/staff/add_borrower", methods=["POST"])
def staff_add_borrower():
    firstname = request.form.get("firstname")
    familyname = request.form.get("familyname")
    dateofbirth = request.form.get("dateofbirth")
    housenumbername = request.form.get("housenumbername")
    street = request.form.get("street")
    town = request.form.get("town")
    city = request.form.get("city")
    postalcode = request.form.get("postalcode")

    connection = getCursor()
    connection.execute("INSERT INTO borrowers (firstname, familyname, dateofbirth, housenumbername, street, town, city, postalcode) VALUES(%s, %s, CAST(%s AS datetime), %s, %s, %s, %s, %s);", (firstname, familyname, dateofbirth, housenumbername, street, town, city, postalcode))
    return redirect("/staff/listborrowers")

@app.route("/staff/loan_detail/<bookcopyid>")
def loandetail(bookcopyid):
    connection = getCursor()
    connection.execute("select * from borrowers;")
    borrowerList = connection.fetchall()
    return render_template("staff_loan_detail.html", bookcopyid=bookcopyid, borrowerlist=borrowerList)

@app.route("/staff/loan/add", methods=["POST"])
def addloan():
    borrowerid = request.form.get('borrowerid')
    bookid = request.form.get('bookcopyid')
    
    cur = getCursor()
    cur.execute("select format from bookcopies where bookcopyid=%s;" %bookid)
    borrower = cur.fetchone()
    b_format = borrower[0]
    print(b_format)
    if(b_format == "eBook" or b_format == "Audio Book"):
        cur.execute("INSERT INTO loans (borrowerid, bookcopyid, loandate, returned) VALUES(%s,%s,now(),1);",(borrowerid, bookid,))
    else:
        cur.execute("INSERT INTO loans (borrowerid, bookcopyid, loandate, returned) VALUES(%s,%s,now(),0);",(borrowerid, bookid,))
    return redirect("/staff/currentloans")

@app.route("/listborrowers")
def listborrowers():
    connection = getCursor()
    connection.execute("SELECT * FROM borrowers;")
    borrowerList = connection.fetchall()
    return render_template("borrowerlist.html", borrowerlist = borrowerList)

@app.route("/staff/currentloans")
def currentloans():
    connection = getCursor()
    sql=""" select br.borrowerid, br.firstname, br.familyname,  
                l.borrowerid, l.bookcopyid, l.loandate, l.returned, b.bookid, b.booktitle, b.author, 
                b.category, b.yearofpublication, bc.format,
                datediff(now(), l.loandate) as day,
                l.loanid
            from books b
                inner join bookcopies bc on b.bookid = bc.bookid
                    inner join loans l on bc.bookcopyid = l.bookcopyid
                        inner join borrowers br on l.borrowerid = br.borrowerid
            where l.returned = 0
            order by br.familyname, br.firstname, l.loandate;"""
    connection.execute(sql)
    loanList = connection.fetchall()
    return render_template("currentloans.html", loanlist = loanList)

@app.route("/staff/return_loan/<loanid>")
def returnload(loanid):
    connection = getCursor()
    connection.execute("UPDATE loans SET returned=1 where loanid=%s" % loanid)

    return redirect("/staff/currentloans")

@app.route("/staff/overdue_report")
def showoverduereport():
    connection = getCursor()
    connection.execute("""select * from borrowers where borrowerid in
    (select borrowerid from loans
    where datediff(now(), loans.loandate) > 35 and returned = 0
    GROUP BY borrowerid)""")
    report_list = []
    borrowerlist = connection.fetchall()
    for borrower in borrowerlist:
        lt_borrower = list(borrower)
        connection.execute("""
        select loans.bookcopyid,loans.loandate, datediff(now(),loans.loandate)-35, books.* from loans
        inner join bookcopies on loans.bookcopyid = bookcopies.bookcopyid
        inner join books on books.bookid = bookcopies.bookid
        where datediff(now(), loans.loandate) > 35 and returned = 0
        and borrowerid = %s""" %lt_borrower[0])
        booklist = connection.fetchall()
        lt_borrower.append(booklist)
        report_list.append(lt_borrower)
    print(report_list)
    return render_template("staff_overdue_report.html", reportlist = report_list)

